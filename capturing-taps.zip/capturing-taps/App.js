import { View, Button, Alert, SafeAreaView, StyleSheet } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';


export default function App() {
  
    const handlePress = () => {
          Alert.alert('Hello');
    };

    return (
          <SafeAreaView style={styles.container}> 
            <Button style={styles.button}
              title="Press me"
              onPress={handlePress}
            />
          </SafeAreaView>
        );
}


const styles = StyleSheet.create({
  button: {
    flex: 1,
    alignContent: 'center',
    justifyContent: 'center',
    padding: 150,
    borderRadius: 5
  },
   container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },

});

